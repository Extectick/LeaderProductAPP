import Navigation from '@/components/Navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import React from 'react';

const MainScreen: React.FC = () => {
  return (
    <ProtectedRoute>
      <Navigation />
    </ProtectedRoute>
  );
};

export default MainScreen;
