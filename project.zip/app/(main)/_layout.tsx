import ProtectedRoute from '@/components/ProtectedRoute';
import { Tabs } from 'expo-router';
import React from 'react';

export default function MainLayout() {
  return (
    <ProtectedRoute>
      <Tabs screenOptions={{ headerShown: false }}>
        <Tabs.Screen name="index" />
        <Tabs.Screen name="tasks" />
        <Tabs.Screen name="profile" />
      </Tabs>
    </ProtectedRoute>
  );
}
