import { useRouter } from 'expo-router';
import { useEffect } from 'react';
import { ensureAuth } from '../utils/auth';

export default function Index() {
  const router = useRouter();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = await ensureAuth();
        if (token) {
          router.replace('/(main)');
        } else {
          router.replace('/AuthScreen');
        }
      } catch {
        router.replace('/AuthScreen');
      }
    };

    checkAuth();
  }, []);

  return null;
}
