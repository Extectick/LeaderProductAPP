import { Stack } from "expo-router";

export default function QrCodesLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}
